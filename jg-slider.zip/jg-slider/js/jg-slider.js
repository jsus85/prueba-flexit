jQuery(document).ready(function(){
  jQuery('.bxslider').bxSlider({
  mode: 'fade',
  captions: true
});
});
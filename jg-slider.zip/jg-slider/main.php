<?php
/**
 * Plugin Name: JG Slider de imagenes
 * Plugin URI: https://www.facebook.com/jsus85
 * Description: JG Slider de imagenes 
 * Version: 1.0.0
 * Author: Jesus Guevara
 * Author URI: https://www.facebook.com/jsus85
 * Requires at least: 4.0
 * Tested up to: 4.3
 *
 * Text Domain: https://www.facebook.com/jsus85
 * Domain Path: /languages/
 */
defined( 'ABSPATH' ) or die( '¡Sin trampas!' );

wp_enqueue_style( 'jg-slider', '/wp-content/plugins/jg-slider/css/jg-slider.css',false,'1.1','all');
wp_enqueue_style( 'jg-slider2', '/wp-content/plugins/jg-slider/css/jquery.bxslider.css',false,'1.1','all');
wp_enqueue_script( 'jg-script', '/wp-content/plugins/jg-slider/js/jquery.bxslider.min.js', array ( 'jquery' ), 1.1, true);
wp_enqueue_script( 'jg-script2', '/wp-content/plugins/jg-slider/js/jg-slider.js', array ( 'jquery' ), 1.1, true);

// Incluir Explorador de imagenes
add_action( 'admin_enqueue_scripts', 'load_admin_things' );
function load_admin_things() {
    wp_enqueue_script('media-upload');
    wp_enqueue_script('thickbox');
    wp_enqueue_style('thickbox');
}


add_action('admin_head', 'my_custom_fonts');
function my_custom_fonts() {
  echo '<style>
				#listTable tr td{border-bottom:1px solid #CCC;border-top:1px solid #CCC;padding:5px}	
				#HTML_imagenes{margin-left: 20px;}
  </style>';
}


// Registers the new post type and taxonomy
add_action( 'init', 'wpt_slider_posttype' );
function wpt_slider_posttype() {

	register_post_type( 'jg-slider',
		
		array(
				'labels' => array(
				'name' => __( 'JG Slider' ),
				'singular_name' => __( 'JG Slider' ),
				'add_new' => __( 'Agregar Slider' ),
				'add_new_item' => __( 'Agregar Slider' ),
				'edit_item' => __( 'Editar Slider' ),
				'new_item' => __( 'Agregar nuevo Slider' ),
				'view_item' => __( 'View Slider' ),
				'search_items' => __( 'Buscar Slider' ),
				'not_found' => __( 'No events found' ),
				'not_found_in_trash' => __( 'No events found in trash' )
			),
				'public' => true,
				'supports' => array( 'title' ),
				'capability_type' => 'post',
				'rewrite' => array("slug" => "jg-slider"), // Permalinks format
				'menu_position' => 5,
				'menu_icon' => 'dashicons-format-gallery',
				'register_meta_box_cb' => 'add_sliders_metaboxes'
		)
	);
}



// Add the Events Meta Boxes
add_action( 'add_meta_boxes', 'add_sliders_metaboxes' );
function add_sliders_metaboxes() {
	add_meta_box('wpt_sliders_location', 'Agregar Imagenes', 'wpt_sliders_location', 'jg-slider', 'normal', 'high');
}

// The Event Location Metabox
function wpt_sliders_location() {
	
	global $post;
	global $wpdb;
	
	$url = 'https://dummyimage.com/100x100/000/fff';

	$metas = $wpdb->get_results($wpdb->prepare("SELECT 
													meta_value,meta_id 
												FROM
														 $wpdb->postmeta 
												where
														 post_id = '".$post->ID."' and 
														 meta_key = %s order by meta_id desc", 'my-image-for-post'));


	if( count($metas) > 0 ){ #check if we got any results
?>
	<table id="listTable" cellpadding="2" cellspacing="2" style="padding: 10px;margin: 10px;width: 99%">
		<?php
			$x=1;
			foreach ($metas as $meta){
		?>
		<tr>
			<td align="center" valign="top"><img src="<?php echo $meta->meta_value;?>" style="width:80px;height: 50px" id="picsrc_edit<?php echo $x;?>" /></td>
			<td valign="top">
				<input type="hidden" name="HddId[]" id="HddId[]" value="<?php echo $meta->meta_id;?>" />
				<input id="my_image_URL_edit<?php echo $x;?>" readonly="readonly" name="my_image_URL_edit[]" rea type="text" value="<?php echo $meta->meta_value;?>"  style="width:400px;" />
    			<input onclick="showImageEdit('<?php echo $x;?>')"  type="button" value="Upload Image" />
    		</td>
			<td align="center"><a href="#">Eliminar</a></td>
		</tr>
		<?php
				$x++;
				}			
		?>
	</table>
	<?php
			} // IF count 
	 ?>

	<table>
		<tr>
			<td><h3>Nuevas Imagenes</h3></td>
			<td></td>
			<td align="right"><input type="button" class="button button-primary button-large" name="" onclick="add();" value="Agregar otra imagen" /></td>
		</tr>
		<tr><td colspan="3"></td></tr>
		<tr>
			<td align="center" valign="top"><img src="<?php echo $url;?>" style="width:100px;" id="picsrc1" /></td>
			<td valign="top">
				<input id="my_image_URL1" readonly="readonly" name="my_image_URL[]" rea type="text" value=""  style="width:400px;" />
    			
    		</td>
    		<td valign="top" align="left"><input onclick="showImage('1')"  type="button" value="Upload Image" /></td>
		</tr>
	</table>

	<div id="HTML_imagenes"></div>	

    <script type="text/javascript">

    	var i = 1;
   		function add(){   			
   			i++;
   			jQuery( "#HTML_imagenes" ).append( '<table><tr><td valign="top" align="center"><img src="<?php echo $url;?>" style="width:100px;" id="picsrc'+i+'" /></td><td valign="top"><input readonly="readonly" id="my_image_URL'+i+'" name="my_image_URL[]" type="text" value=""  style="width:400px;" /></td><td align="left" valign="top"><input onclick="showImage('+i+')" type="button" value="Upload Image" /></td></tr></table>' );

   		}

   		function showImage(i){

   			window.send_to_editor = function(html) {
                imgurl = jQuery(html).attr('src')
                jQuery('#my_image_URL'+i).val(imgurl);
                jQuery('#picsrc'+i).attr("src",imgurl);
                tb_remove();
            }

            formfield = jQuery('#my_image_URL'+i).attr('name');
            tb_show( '', 'media-upload.php?type=image&amp;TB_iframe=true' );
            
            return false;
   		}


   		function showImageEdit(i){
			
			window.send_to_editor = function(html) {
                imgurl = jQuery(html).attr('src')
                jQuery('#my_image_URL_edit'+i).val(imgurl);
                jQuery('#picsrc_edit'+i).attr("src",imgurl);
                tb_remove();
            }

            formfield = jQuery('#my_image_URL_edit'+i).attr('name');
            tb_show( '', 'media-upload.php?type=image&amp;TB_iframe=true' );
            
            return false;
   		}



    </script>
<?php 

}	


// Guardar Informacion 
add_action( 'save_post', function ($post_id) {
    
    // Insertar 	
    if (isset($_POST['my_image_URL'])){    	
    	foreach ($_POST['my_image_URL'] as $key ) {
			//update_post_meta($post_id, 'my-image-for-post',$key);
			if($key!=''){
				add_post_meta($post_id, 'my-image-for-post',$key);
			}				
		}
     }

	     // Actualizar
     	$imagen     = $_POST['my_image_URL_edit'];
     	$idPostMeta = $_POST['HddId'];
     	global $wpdb;

			if (isset($imagen)) {
					
					foreach( $imagen as $key => $img ) {

						$wpdb->update( 
							$wpdb->postmeta, 
								array( 'meta_value' => $img), 
								array( 'meta_id' => $idPostMeta[$key]), 
								array( '%s'), 
								array( '%d' ) 
						);

					}
			}		

});

// -----  Box: Mostrar Texto para el  SHORCOTE ------
add_action("add_meta_boxes", "add_custom_meta_box");
function add_custom_meta_box(){
    add_meta_box("demo-meta-box", "Uso - Shorcote", "custom_meta_box_markup", "jg-slider", "side", "high", null);
}

function custom_meta_box_markup()
{
	global $post;
	echo "<p><i>Copia y pega el shortcode directamente en cualquier página o entrada de WordPress.</i></p>";
	echo "<p>[jgslider id=".$post->ID."]</p>";
}
// ----  Box: SHORCOTE ---


// Crear Shorcote Slider
function jg_slider($atts){  
	
	$p = shortcode_atts( array ('id' => ''), $atts );  	
	//$texto = '<marquee>Este es el ID: '.$p['id'].'</marquee>';  

	global $wpdb;
	$metas = $wpdb->get_results($wpdb->prepare("SELECT 
													meta_value,meta_id 
												FROM
														 $wpdb->postmeta 
												where
														 post_id = ".$p['id']." and 
														 meta_key = %s order by meta_id desc", 'my-image-for-post'));

	

	
  
  


	$texto ='';
	$texto .='<ul class="bxslider">';

	foreach ($metas as $meta){
		$texto .= '<li><img src="'.$meta->meta_value.'" /></li>';

	}					
	$texto .='</ul>';



	return $texto;  
}  

add_shortcode('jgslider','jg_slider');  
// Fin: Shorcote Slider



